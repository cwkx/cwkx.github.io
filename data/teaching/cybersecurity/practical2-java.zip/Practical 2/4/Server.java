import com.sun.net.httpserver.BasicAuthenticator;
import com.sun.net.httpserver.Headers;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

public class Server {

    public void run() throws Exception {
        HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);
        server.createContext("/", new RootHandler());
        server.start();
        System.out.println("Server is running. Navigate the browser to: http://127.0.0.1:8000/");
    }

    class RootHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange t) throws IOException {
            String root = "./";
            URI uri = t.getRequestURI();
            String path = uri.getPath();

            // Redirect empty requests to index.html
            if (path.equals("/"))
                path = "/index.html";

            System.out.println("looking for: " + path);
            File file = new File(root + path).getCanonicalFile();
            if (!file.isFile()) {
                // Object does not exist or is not a file: reject with 404 error.
                String response = "404 (Not Found)\n";
                t.sendResponseHeaders(404, response.length());
                OutputStream os = t.getResponseBody();
                os.write(response.getBytes());
                os.close();
            } else {
                // Object exists and is a file: accept with response code 200.
                String mime = "text/html";
                if (path.substring(path.length() - 3).equals(".js"))
                    mime = "application/javascript";
                if (path.substring(path.length() - 3).equals("css"))
                    mime = "text/css";
                Headers h = t.getResponseHeaders();
                h.set("Content-Type", mime);
                t.sendResponseHeaders(200, 0);
                OutputStream os = t.getResponseBody();
                FileInputStream fs = new FileInputStream(file);
                final byte[] buffer = new byte[0x10000];
                int count = 0;
                while ((count = fs.read(buffer)) >= 0) {
                    os.write(buffer, 0, count);
                }
                fs.close();
                os.close();
            }
        }
    }

    public static void main(String[] args) throws Exception {
        new Server().run();
    }
}