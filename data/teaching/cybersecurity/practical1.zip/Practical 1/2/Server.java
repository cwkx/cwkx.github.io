import com.sun.net.httpserver.BasicAuthenticator;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;
import java.io.File;
import java.io.IOException;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.util.Arrays;
import java.util.List;
import java.util.ArrayList;

public class Server {

    // Bad storage of usernames and passwords
    private List<String> users = Arrays.asList("admin", "chris", "greg", "john", "test");
    private List<String> passwords = Arrays.asList("12345qwert", "ncc1701d", "zxcvbn", "1qaz2wsx", "ncc1701d");

    public void run() throws Exception {
        BasicAuthenticator auth = new BasicAuthenticator("get") {
            @Override
            public boolean checkCredentials(String user, String pass) {

                // Check if login was successful
                for (int i = 0; i < users.size(); ++i) {
                    if (user.equals(users.get(i)) && pass.equals(passwords.get(i))) {
                        System.out.println(users.get(i) + " has logged in!");
                        return true;
                    }
                }
                return false;
            }
        };
        // Setup and start the server
        final HttpServer server = HttpServer.create(new InetSocketAddress(8000), 0);
        server.createContext("/login", new MyHandler(
                "Welcome valid user!\n\nHere is your secret bitcoin private key: KworuAjAtnxPhZARLzAadg9WTVKjY4kckS8pw38JrD33CeVYUuDm.\n\nHappy spending!"))
                .setAuthenticator(auth);
        server.setExecutor(null);
        server.start();
    }

    static class MyHandler implements HttpHandler {
        private String message;

        public MyHandler(String message) {
            this.message = message;
        }

        @Override
        public void handle(HttpExchange t) throws IOException {
            String response = message;
            t.sendResponseHeaders(200, response.length());
            OutputStream os = t.getResponseBody();
            os.write(response.getBytes());
            os.close();
        }
    }

    public static void main(String[] args) throws Exception {
        new Server().run();
    }
}
